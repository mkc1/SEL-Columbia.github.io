%function [total_cost, gen_cost, production_cost, without_cost, t_g_per, heat_per, max_capacity, gen_heat, gen_elec] = HW5_func_copy(number_turbines)
clear

%number_turbines = [0 10000 20000 30000 40000];
%number_turbines = 0:1000:60000;
number_turbines = [10000];

heat_data = xlsread('nyheatdemand');
heat_demand = heat_data(:,1);
elec_demand = xlsread('nyelecdemand');
wspd_init = xlsread('NY_wind');
wspd_corr = wspd_init * ((80/100) ^ .3);


for k = 1:length(number_turbines)
    
for j = 1:length(wspd_corr)
    power(j) = power_func(wspd_corr(j)) * number_turbines(k);
end
power_MW = power / 1e6;

total_production(k) = trapz(power_MW);
total_heatdemand = trapz(heat_demand);
total_elecdemand = trapz(elec_demand);

to_heat = zeros(1, 8760);

boiler_count = 0;
GT_count = 0;

storage = 0;
storage_input = 0;
storage_output = 0;
elec_to_heat = 0;
gen_supplied_heat = zeros(1, 8760);
gen_supplied_elec = zeros(1, 8760);
storage_array = zeros(1, 8760);
throwaway = zeros(1, 8760);
elec_to_heat = zeros(1, 8760);
needed_heat = zeros(1, 8760);

for i = 1:8760
    elec_deficit(i) = power_MW(i) - elec_demand(i);
    %surplus of wind power
    if elec_deficit(i) > 0
        to_elec(i) = elec_demand(i);
        elec_surplus = elec_deficit(i);
        %elec_surplus = 0; %no elec used for heating with this uncommented
        elec_to_heat(i) = elec_surplus; %does not consider ratio
        %electricity demand surplus supplies heat power in 1:4 ratio of
        %electricty:heat
        heat_deficit(i) = (elec_surplus * 4) - heat_demand(i);
        
        %heat power goes to storage(heats up water) (only case where
        %storage is increasing)
        if heat_deficit(i) > 0 
            heat_surplus = heat_deficit(i);
            storage_space = 176.11e3 - storage;
            if heat_surplus >= storage_space
                storage = 176.11e3;
                storage_input = storage_input + storage_space;
                throwaway(i) = (heat_surplus - storage_space)/4; %convert from heat back to elec units 
            else
                storage = storage + heat_surplus;
                storage_input = storage_input + heat_surplus;
            end
            storage_array(i) = storage;
        end
        
        %if excess wind power cannot supply heat demand, and storage can
        %cover
        if (heat_deficit(i) < 0) && ((heat_deficit(i) + storage) >= 0)
            storage = storage + heat_deficit(i);
            storage_output = storage_output + abs(heat_deficit(i));
            storage_array(i) = storage;
        end
        
        %need to use boiler
        if (heat_deficit(i) < 0) && ((heat_deficit(i) + storage) < 0)
            needed_heat(i) = heat_deficit(i) + storage; %using remaining storage
            gen_supplied_heat(i) = abs(needed_heat(i)); %1.1:1 ratio of GT:space heating
            boiler_count = boiler_count + 1;
            storage_output = storage_output + storage;
            storage = 0;
            storage_array(i) = storage;
        end
    end
    
    if elec_deficit(i) == 0;
        to_elec(i) = elec_demand(i);
        needed_heat(i) = heat_demand(i) - storage;
        if needed_heat(i) <= 0 % => storage >= heat_demand
            storage = storage - heat_demand(i);
            storage_output = storage_output + heat_demand(i);
        end

        if needed_heat(i) > 0 
            gen_supplied_heat(i) = (needed_heat(i));
            B_count = B_count + 1;
            storage_output = storage_output + storage;
            storage = 0;
        end
        storage_array(i) = storage;  
    end
 
    if elec_deficit(i) < 0
        to_elec(i) = power_MW(i);
        GT_count = GT_count + 1;
        gen_supplied_elec(i) = abs(elec_deficit(i));
        
        needed_heat(i) = heat_demand(i) - storage;
        %if negative, storage can meet
        %if positive, need to draw from GT
        
        if needed_heat(i) <= 0
            storage = storage - heat_demand(i);
            storage_output = storage_output + heat_demand(i); 
        end
        
        if needed_heat(i) > 0
            gen_supplied_heat(i) = abs(needed_heat(i));
            boiler_count = boiler_count + 1;
            storage_output = storage_output + storage;
            storage = 0;
        end
        storage_array(i) = storage;
    end
end
end

%end