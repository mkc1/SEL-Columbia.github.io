%3

function [ Cp ] = p_coeff( x )
%This function returns a power function for a given wind speed based on a
%1.5 MW turbine

p1 =  -3.527e-05;
p2 =    0.002445;
p3 =    -0.05964;
p4 =      0.5713;
p5 =      -1.411;
Cp = p1*x^4 + p2*x^3 + p3*x^2 + p4*x + p5;

end