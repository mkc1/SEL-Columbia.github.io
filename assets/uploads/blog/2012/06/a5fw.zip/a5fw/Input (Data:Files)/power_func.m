
function [ wind_power ] = power_func( x )

if x < 4 || x > 25
    wind_power = 0;
    
elseif x > 14 && x <= 25
    wind_power = 1500000;

else
    wind_power = .5 * 1.2 * (pi * (67.2/2)^2) * p_coeff(x) * (x ^ 3);
end
end

