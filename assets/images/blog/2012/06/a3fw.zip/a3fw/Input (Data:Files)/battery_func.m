function [ storage_array, storage_input, storage_output, not_supplied ] = battery_func(power_MW, demand_data)
%Calculates the input and output from a battery connected to a turbine
%system

storage = 0;
storage_input = 0;
storage_output = 0;
not_supplied = 0;
storage_array = 0;


for k = 1:length(power_MW)

deficit = (power_MW(k)) - demand_data(k);
    
    %case (a)
    if deficit > 0
        storage = storage + deficit;
        storage_input = storage_input + deficit;
        storage_array(k) = storage;
    end
    
    %case (b)
    if deficit < 0 && (storage + deficit) >= 0
        storage = storage + deficit;
        storage_output = storage_output + abs(deficit); 
        storage_array(k) = storage;
        %not supplied does not change because energy from the battery
        %covers it
    end
    
    %case (c) 
    if deficit < 0 && (storage + deficit) < 0
        not_supplied = not_supplied + (storage + deficit); %using remaining storage
        storage = 0;
        storage_output = storage_output + storage;
        storage_array(k) = storage;
    end 

end
end

