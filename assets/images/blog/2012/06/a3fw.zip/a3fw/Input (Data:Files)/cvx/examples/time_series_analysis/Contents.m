% Example from [http://stanford.edu/~boyd/papers/l1_trend_filter.html $\ell_1$ Trend Filtering]
%
%  l1_trend_filter_snp500.m - l1 trend filtering
%  snp500.txt               - (no title)
help Contents
